const form = document.getElementById('donateForm');
const message = document.getElementById('formMessage');

form.addEventListener('submit', function (event) {
    event.preventDefault();

    const formData = new FormData(form);
    const name = formData.get('name');
    const type = formData.get('type');

    const typeLabels = {
        participant: 'учасника події',
        volunteer: 'волонтера',
        donor: 'благодійника'
    };

    message.textContent = `${name}, заявку ${typeLabels[type]} успішно сформовано. Дякуємо за підтримку!`;
    form.reset();
});
